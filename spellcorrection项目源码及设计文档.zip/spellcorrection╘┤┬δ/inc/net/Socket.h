 ///
 /// @file    Socket.h
 /// @author  rxianjin@163.com
 ///

 
#ifndef _MY_SOCKET_H_
#define _MY_SOCKET_H_

#include "Noncopyable.h"

namespace wd
{
class InetAddress;

class Socket : Noncopyable
{
public:
	Socket();
	Socket(int);
	void ready(InetAddress & addr);
	int accept();
	int fd();

	void shutdownWrite();

	static InetAddress getLocalAddr(int fd);
	static InetAddress getPeerAddr(int fd);
private:
	void setReuseAddr(bool flag);
	void setReusePort(bool flag);
	void bind(InetAddress & addr);
	void listen();
private:
	int _fd;
};

}// end of namespace wd 

#endif
